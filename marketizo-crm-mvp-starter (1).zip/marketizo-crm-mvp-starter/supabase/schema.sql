create extension if not exists "uuid-ossp";

create table clients (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  contact_email text,
  contact_phone text,
  created_at timestamp with time zone default now()
);

create table leads (
  id uuid primary key default uuid_generate_v4(),
  client_id uuid references clients(id) on delete cascade,
  name text not null,
  phone text not null,
  email text,
  source text default 'Meta Ads',
  status text default 'Novi',
  tags text[] default '{}',
  campaign_name text,
  form_name text,
  note text,
  raw_payload jsonb,
  contacted_at timestamp with time zone,
  created_at timestamp with time zone default now()
);

create table lead_events (
  id uuid primary key default uuid_generate_v4(),
  lead_id uuid references leads(id) on delete cascade,
  event_type text not null,
  message text,
  created_at timestamp with time zone default now()
);

create index leads_client_idx on leads(client_id);
create index leads_status_idx on leads(status);
create index leads_created_at_idx on leads(created_at desc);
