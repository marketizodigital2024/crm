import './globals.css';

export const metadata = {
  title: 'Marketizo CRM MVP',
  description: 'Marketizo Lead Panel'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="sr">
      <body>{children}</body>
    </html>
  );
}
