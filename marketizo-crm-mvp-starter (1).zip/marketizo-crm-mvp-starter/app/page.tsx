'use client';

import { useMemo, useState } from 'react';
import { mockLeads, statuses, monthNames } from '@/lib/mockLeads';

type Lead = typeof mockLeads[number];

export default function Home() {
  const [leads, setLeads] = useState<Lead[]>(mockLeads);
  const [activeStatus, setActiveStatus] = useState('Svi');
  const [search, setSearch] = useState('');
  const [month, setMonth] = useState('');
  const [year, setYear] = useState('');
  const [tag, setTag] = useState('');
  const [source, setSource] = useState('');
  const [showForm, setShowForm] = useState(false);

  const tags = useMemo(() => Array.from(new Set(leads.flatMap(l => l.tags))).sort(), [leads]);
  const years = useMemo(() => Array.from(new Set(leads.map(l => new Date(l.date).getFullYear()))).sort((a,b)=>b-a), [leads]);

  const filtered = leads.filter(l => {
    const d = new Date(l.date);
    const hay = `${l.name} ${l.phone} ${l.email} ${l.tags.join(' ')}`.toLowerCase();
    return (!search || hay.includes(search.toLowerCase()))
      && (!month || d.getMonth()+1 === Number(month))
      && (!year || d.getFullYear() === Number(year))
      && (!tag || l.tags.includes(tag))
      && (!source || l.source === source)
      && (activeStatus === 'Svi' || l.status === activeStatus);
  });

  const addLead = (e: any) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const newLead: Lead = {
      id: String(Date.now()),
      name: String(fd.get('name')),
      phone: String(fd.get('phone')),
      email: String(fd.get('email') || ''),
      source: String(fd.get('source')),
      status: 'Novi',
      tags: String(fd.get('tags') || 'Preporuka').split(',').map(t => t.trim()).filter(Boolean),
      date: new Date().toISOString()
    };
    setLeads([newLead, ...leads]);
    setShowForm(false);
    e.currentTarget.reset();
    alert('Novi lead je dodat. U pravoj verziji ovde ide instant notifikacija klijentu.');
  };

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="logo">MD<span>MARKETIZO</span></div>
        <nav className="nav">
          <a className="active">Leadovi</a>
          <a>Statistika</a>
          <a>Poruke</a>
          <a>Podešavanja</a>
        </nav>
        <div className="clientBox">Klijent demo<br/><b>Ivanović Osiguranje</b></div>
      </aside>

      <main className="main">
        <div className="top">
          <div>
            <h1>Leadovi</h1>
            <div className="subtitle">Meta, funnel, preporuke i ručni unos — sve na jednom mestu.</div>
          </div>
          <button className="btn primary" onClick={() => setShowForm(!showForm)}>+ Novi lead</button>
        </div>

        {showForm && (
          <form className="formBox" onSubmit={addLead}>
            <b>Ručni unos leada</b>
            <div className="formGrid">
              <input name="name" placeholder="Ime i prezime" required />
              <input name="phone" placeholder="Telefon" required />
              <input name="email" placeholder="Email" />
              <select name="source" defaultValue="Preporuka">
                <option>Preporuka</option>
                <option>Telefon</option>
                <option>Walk In</option>
                <option>Instagram</option>
                <option>Facebook</option>
                <option>Meta Ads</option>
                <option>Website</option>
              </select>
            </div>
            <input name="tags" placeholder="Tagovi, odvojeni zarezom: Hot, VIP, Preporuka" />
            <button className="btn primary">Sačuvaj lead</button>
          </form>
        )}

        <section className="stats">
          <div className="card"><div className="number">{filtered.length}</div><div className="label">Ukupno leadova</div></div>
          <div className="card"><div className="number">{filtered.filter(l=>l.status==='Novi').length}</div><div className="label">Novi leadovi</div></div>
          <div className="card"><div className="number">{filtered.filter(l=>l.status==='Zakazan').length}</div><div className="label">Zakazano</div></div>
          <div className="card"><div className="number">{filtered.filter(l=>l.status==='Klijent').length}</div><div className="label">Klijenti</div></div>
        </section>

        <section className="toolbar">
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Pretraži ime, telefon ili tag..." />
          <select value={month} onChange={e=>setMonth(e.target.value)}>
            <option value="">Svi meseci</option>
            {monthNames.map((m,i)=><option key={m} value={i+1}>{m}</option>)}
          </select>
          <select value={year} onChange={e=>setYear(e.target.value)}>
            <option value="">Sve godine</option>
            {years.map(y=><option key={y} value={y}>{y}</option>)}
          </select>
          <select value={tag} onChange={e=>setTag(e.target.value)}>
            <option value="">Svi tagovi</option>
            {tags.map(t=><option key={t}>{t}</option>)}
          </select>
          <select value={source} onChange={e=>setSource(e.target.value)}>
            <option value="">Svi izvori</option>
            {Array.from(new Set(leads.map(l=>l.source))).map(s=><option key={s}>{s}</option>)}
          </select>
        </section>

        <div className="tabs">
          {statuses.map(s => (
            <button key={s} onClick={()=>setActiveStatus(s)} className={`tab ${activeStatus===s?'active':''}`}>{s}</button>
          ))}
        </div>

        <section className="leadList">
          {filtered.map(l => {
            const wa = 'https://wa.me/' + l.phone.replace(/\D/g,'');
            return (
              <article className="lead" key={l.id}>
                <div><div className="name">{l.name}</div><div className="muted">{l.phone}</div></div>
                <div className="muted">{l.source}</div>
                <div className="muted">{new Date(l.date).toLocaleDateString('sr-RS')}</div>
                <div><span className={`badge ${l.status}`}>{l.status}</span><div className="muted">{l.tags.join(' • ')}</div></div>
                <div className="actions">
                  <a className="btn" href={`tel:${l.phone}`}>📞 Pozovi</a>
                  <a className="btn" href={wa} target="_blank">WhatsApp</a>
                </div>
              </article>
            );
          })}
        </section>
      </main>
    </div>
  );
}
