import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function POST(req: NextRequest) {
  const secret = req.headers.get('x-marketizo-secret');
  if (secret !== process.env.MARKETIZO_WEBHOOK_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json();

  const lead = {
    client_id: body.client_id,
    name: body.name,
    phone: body.phone,
    email: body.email || null,
    source: body.source || 'Meta Ads',
    status: 'Novi',
    tags: body.tags || [],
    campaign_name: body.campaign_name || null,
    form_name: body.form_name || null,
    raw_payload: body
  };

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

  if (!supabaseUrl || !serviceKey) {
    return NextResponse.json({
      ok: true,
      mode: 'demo',
      message: 'Lead primljen, ali Supabase nije povezan.',
      lead
    });
  }

  const supabase = createClient(supabaseUrl, serviceKey);
  const { data, error } = await supabase.from('leads').insert(lead).select().single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  // Ovde kasnije ide:
  // 1. Push notifikacija u browser / mobilnu aplikaciju
  // 2. WhatsApp poruka klijentu
  // 3. Email/SMS backup ako nije otvorio lead

  return NextResponse.json({ ok: true, lead: data });
}
