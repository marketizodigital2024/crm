# Meta Instant Form -> Make -> Marketizo CRM

## Scenario u Make-u

1. Trigger: Facebook Lead Ads - New Lead
2. Action: Webhooks - Make a request
3. Method: POST
4. URL:
   https://tvoj-vercel-link.vercel.app/api/leads/webhook
5. Headers:
   x-marketizo-secret: vrednost-iz-env-fajla
   Content-Type: application/json
6. Body primer:

```json
{
  "client_id": "SUPABASE_CLIENT_ID",
  "name": "{{full_name}}",
  "phone": "{{phone_number}}",
  "email": "{{email}}",
  "source": "Meta Ads",
  "campaign_name": "{{campaign.name}}",
  "form_name": "{{form.name}}",
  "tags": ["Meta", "Novi"]
}
```

Kada neko popuni Meta Instant Form, Make šalje podatke u Marketizo CRM.
