# Roadmap

## MVP
- Dashboard
- Lead lista
- Filteri
- Ručni unos
- Webhook za leadove
- WhatsApp klik
- Poziv klik

## V1
- Login
- Klijent vidi samo svoje leadove
- Admin vidi sve klijente
- Supabase baza
- Real-time update kada stigne lead
- Browser notifikacija

## V2
- WhatsApp Cloud API notifikacije
- Reminder ako lead nije pozvan za 15 min
- SLA report
- Brzina reakcije klijenta
- Kampanje i forme po klijentu

## V3
- Marketizo funnel builder
- Booking
- AI follow-up
- AI lead scoring
