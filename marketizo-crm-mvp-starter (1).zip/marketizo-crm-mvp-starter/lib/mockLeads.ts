export const mockLeads = [
  { id:'1', name:'Marko Petrović', phone:'+381 64 123 4567', email:'marko@test.com', source:'Meta Ads', status:'Novi', tags:['Osiguranje','Hot'], date:'2026-07-05T10:21' },
  { id:'2', name:'Jelena Stanković', phone:'+381 65 987 6543', email:'jelena@test.com', source:'Meta Ads', status:'Novi', tags:['Auto','Warm'], date:'2026-07-05T09:55' },
  { id:'3', name:'Nikola Jovanović', phone:'+381 63 456 7890', email:'nikola@test.com', source:'Marketizo Funnel', status:'Kontaktiran', tags:['Biznis','Hot'], date:'2026-06-18T12:10' },
  { id:'4', name:'Ana Milovanović', phone:'+381 62 345 6789', email:'ana@test.com', source:'Website', status:'Zakazan', tags:['Zdravstvo'], date:'2026-06-11T15:44' },
  { id:'5', name:'Milan Kovačević', phone:'+381 61 234 5678', email:'milan@test.com', source:'Meta Ads', status:'Klijent', tags:['Osiguranje'], date:'2026-05-25T11:30' },
  { id:'6', name:'Marija Ilić', phone:'+381 60 111 2222', email:'marija@test.com', source:'Preporuka', status:'Nezainteresovan', tags:['Cold'], date:'2025-12-14T17:02' }
];

export const statuses = ['Svi','Novi','Kontaktiran','Zakazan','Klijent','Nezainteresovan'];
export const monthNames = ['Januar','Februar','Mart','April','Maj','Jun','Jul','Avgust','Septembar','Oktobar','Novembar','Decembar'];
